﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HaarlemFestival.Models
{
    public class Dinner : Activity
    {
        public EventType EventType = EventType.DinnerInHaarlem;
        public Restaurant Restaurant { get; set; }
    }
}
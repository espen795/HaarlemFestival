﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HaarlemFestival.Models
{
    public class Historic : Activity
    {
        public EventType EventType = EventType.HistoricHaarlem;
        public string StartLocation { get; set; }
        public Guide Guide { get; set; }
        public Language Language { get; set; }
        public int TotalSeats { get; set; }
        public double Price { get; set; }
        public double GroupPrice { get; set; }
        public bool ReservationMandatory { get; set; }
    }
}
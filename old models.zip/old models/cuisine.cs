﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HaarlemFestival.Models
{
    public class cuisine
    {
        public int CuisineId { get; set; }
        public string CuisineNaam { get; set; }
    }
}